export const jwtConfig = {
  secret: 'bjvbvjfjvnfvkvkfjfkropzsmsxlxkbfghj',
  expiresIn: '31d', // Durée de validité du JWT modifié pour plus de simplicité pour dev
  refreshSecret: 'vfjvjkfjvdjlckjdryijfihjyunhgfnuknhvrftujioknhv',
  refreshExpiresIn: '7d', // Durée de validité du refresh token
}