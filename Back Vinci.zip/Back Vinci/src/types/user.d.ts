export type UserCreation = {
    email: string,
    password: string
    }